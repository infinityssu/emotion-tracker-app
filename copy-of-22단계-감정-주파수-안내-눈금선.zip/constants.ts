
import type { Emotion } from './types';

export const EMOTIONS_SCALE: Emotion[] = [
  { level: 1, koreanName: '기쁨, 감사, 자유, 사랑, 권한 부여', englishName: 'Joy, Gratitude, Freedom, Love, Empowerment', category: 'Positive' },
  { level: 2, koreanName: '열정', englishName: 'Passion', category: 'Positive' },
  { level: 3, koreanName: '열망, 행복', englishName: 'Eagerness, Happiness', category: 'Positive' },
  { level: 4, koreanName: '긍정적 기대, 신념', englishName: 'Positive Expectation, Belief', category: 'Positive' },
  { level: 5, koreanName: '낙관주의', englishName: 'Optimism', category: 'Positive' },
  { level: 6, koreanName: '희망', englishName: 'Hopefulness', category: 'Positive' },
  { level: 7, koreanName: '만족', englishName: 'Contentment', category: 'Positive' },
  { level: 8, koreanName: '지루함', englishName: 'Boredom', category: 'Negative' },
  { level: 9, koreanName: '비관주의', englishName: 'Pessimism', category: 'Negative' },
  { level: 10, koreanName: '좌절, 짜증, 조급함', englishName: 'Frustration, Irritation, Impatience', category: 'Negative' },
  { level: 11, koreanName: '압도됨', englishName: 'Overwhelm', category: 'Negative' },
  { level: 12, koreanName: '실망', englishName: 'Disappointment', category: 'Negative' },
  { level: 13, koreanName: '의심', englishName: 'Doubt', category: 'Negative' },
  { level: 14, koreanName: '걱정', englishName: 'Worry', category: 'Negative' },
  { level: 15, koreanName: '비난', englishName: 'Blame', category: 'Negative' },
  { level: 16, koreanName: '낙담', englishName: 'Discouragement', category: 'Negative' },
  { level: 17, koreanName: '분노', englishName: 'Anger', category: 'Negative' },
  { level: 18, koreanName: '복수', englishName: 'Revenge', category: 'Negative' },
  { level: 19, koreanName: '증오, 격노', englishName: 'Hatred, Rage', category: 'Negative' },
  { level: 20, koreanName: '질투', englishName: 'Jealousy', category: 'Negative' },
  { level: 21, koreanName: '불안, 죄책감, 무가치함', englishName: 'Insecurity, Guilt, Unworthiness', category: 'Negative' },
  { level: 22, koreanName: '두려움, 슬픔, 절망, 무력감', englishName: 'Fear, Grief, Despair, Powerlessness', category: 'Negative' },
];

export const EMOTION_MAP_KOREAN = new Map(EMOTIONS_SCALE.map(e => [e.level, e.koreanName]));
export const EMOTION_MAP_ENGLISH = new Map(EMOTIONS_SCALE.map(e => [e.level, e.englishName]));
