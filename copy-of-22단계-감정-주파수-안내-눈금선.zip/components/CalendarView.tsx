import React, { useState, useMemo } from 'react';
import { formatDateToYYYYMMDD } from '../utils/dateUtils';

interface CalendarViewProps {
  selectedDate: Date;
  onDateChange: (date: Date) => void;
  dataMarkers: string[]; // YYYY-MM-DD format
}

const CalendarView: React.FC<CalendarViewProps> = ({ selectedDate, onDateChange, dataMarkers }) => {
  const [currentMonth, setCurrentMonth] = useState(new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1));

  const daysInMonth = useMemo(() => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const date = new Date(year, month, 1);
    const days = [];
    while (date.getMonth() === month) {
      days.push(new Date(date));
      date.setDate(date.getDate() + 1);
    }
    return days;
  }, [currentMonth]);

  const startingDayOfWeek = useMemo(() => currentMonth.getDay(), [currentMonth]);

  const changeMonth = (offset: number) => {
    setCurrentMonth(prev => {
      const newMonth = new Date(prev);
      newMonth.setMonth(prev.getMonth() + offset);
      return newMonth;
    });
  };

  const today = new Date();
  const todayKey = formatDateToYYYYMMDD(today);
  const selectedDateKey = formatDateToYYYYMMDD(selectedDate);

  const markerSet = useMemo(() => new Set(dataMarkers), [dataMarkers]);

  return (
    <div className="bg-white rounded-2xl shadow-lg p-3 sm:p-6">
      <div className="flex justify-between items-center mb-4">
        <button onClick={() => changeMonth(-1)} className="p-2 rounded-full hover:bg-slate-100">&lt;</button>
        <h3 className="font-bold text-base sm:text-lg text-slate-700">
          {currentMonth.toLocaleString('ko-KR', { year: 'numeric', month: 'long' })}
        </h3>
        <button onClick={() => changeMonth(1)} className="p-2 rounded-full hover:bg-slate-100">&gt;</button>
      </div>
      <div className="grid grid-cols-7 gap-1 text-center text-xs sm:text-sm text-slate-500 mb-2">
        {['일', '월', '화', '수', '목', '금', '토'].map(day => <div key={day}>{day}</div>)}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {Array.from({ length: startingDayOfWeek }).map((_, i) => <div key={`empty-${i}`}></div>)}
        {daysInMonth.map(day => {
          const dayKey = formatDateToYYYYMMDD(day);
          const isSelected = dayKey === selectedDateKey;
          const isToday = dayKey === todayKey;
          const hasData = markerSet.has(dayKey);

          return (
            <button
              key={day.toString()}
              onClick={() => onDateChange(day)}
              className={`relative w-full aspect-square flex items-center justify-center rounded-full transition-colors text-sm
                ${isSelected ? 'bg-indigo-600 text-white' : ''}
                ${!isSelected && isToday ? 'bg-indigo-100 text-indigo-700' : ''}
                ${!isSelected && !isToday ? 'hover:bg-slate-100' : ''}
              `}
            >
              {day.getDate()}
              {hasData && <span className={`absolute bottom-1.5 w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-white' : 'bg-emerald-500'}`}></span>}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default CalendarView;