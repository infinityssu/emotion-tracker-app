import React from 'react';

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({ isOpen, onClose, onConfirm, title, message }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-6 text-center">
        <h2 id="modal-title" className="text-lg font-bold text-slate-800 mb-2">{title}</h2>
        <p className="text-sm text-slate-600 mb-6">{message}</p>
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={onClose}
            className="w-full h-12 flex items-center justify-center px-6 bg-slate-200 text-slate-700 font-bold rounded-xl hover:bg-slate-300 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-400"
          >
            아니오
          </button>
          <button
            onClick={onConfirm}
            className="w-full h-12 flex items-center justify-center px-6 bg-rose-500 text-white font-bold rounded-xl hover:bg-rose-600 transition-colors shadow focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-rose-500"
          >
            예
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationModal;