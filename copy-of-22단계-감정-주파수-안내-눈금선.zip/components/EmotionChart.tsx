import React from 'react';
import { ResponsiveContainer, LineChart, CartesianGrid, XAxis, YAxis, Tooltip, Line } from 'recharts';
import { EMOTION_MAP_KOREAN } from '../constants';
import type { Checkpoint } from '../types';

interface EmotionChartProps {
  checkpoints: Checkpoint[];
}

const getEmotionColor = (level: number) => {
  if (level <= 7) return '#10b981'; // Emerald 500
  if (level <= 16) return '#f59e0b'; // Amber 500
  return '#ef4444'; // Red 500
};

const CustomizedDot: React.FC<any> = (props) => {
  const { cx, cy, payload } = props;
  if (!payload || cx === null || cy === null) return null;
  
  return (
    <circle cx={cx} cy={cy} r={5} stroke={getEmotionColor(payload.emotionLevel)} strokeWidth={2} fill="#ffffff" />
  );
};

const CustomTooltip: React.FC<any> = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload as Checkpoint;
      const hour = Math.floor(data.time);
      const minutes = Math.round((data.time - hour) * 60);

      const formattedHour = String(hour).padStart(2, '0');
      const formattedMinutes = String(minutes).padStart(2, '0');
      const formattedTime = `${formattedHour}:${formattedMinutes}`;
  
      return (
        <div className="bg-white p-3 rounded-lg shadow-lg border border-slate-200 max-w-xs">
          <p className="font-bold text-slate-700 text-sm">{`시간: ${formattedTime}`}</p>
          <p className="text-xs text-slate-600">{`${data.emotionLevel}. ${data.koreanName}`}</p>
          {data.reason && (
            <p className="mt-2 pt-2 border-t border-slate-200 text-xs text-slate-500 italic">{data.reason}</p>
          )}
        </div>
      );
    }
    return null;
  };

const CustomYAxisTick = (props: any) => {
    const { x, y, payload } = props;
    const emotionName = EMOTION_MAP_KOREAN.get(payload.value) || '';
    
    const words = emotionName.split(', ');
    const displayLines = [];

    if (words.length > 2) {
        let chunk = [];
        for (const word of words) {
            chunk.push(word);
            if (chunk.length === 3) {
                displayLines.push(chunk.join(', '));
                chunk = [];
            }
        }
        if (chunk.length > 0) {
            displayLines.push(chunk.join(', '));
        }
    } else {
        displayLines.push(emotionName);
    }
    
    if(displayLines.length > 0) {
      displayLines[0] = `${payload.value}. ${displayLines[0]}`;
    }

    return (
        <g transform={`translate(${x}, ${y})`}>
            <text x={0} y={0} dy={3} textAnchor="end" fill="#475569" fontSize={9}>
                {displayLines.map((line, index) => (
                    <tspan x={-5} dy={index > 0 ? '1.2em' : 0} key={index}>
                        {line}
                    </tspan>
                ))}
            </text>
        </g>
    );
};

const EmotionChart: React.FC<EmotionChartProps> = ({ checkpoints }) => {
  if (!checkpoints.length) {
    return (
      <div className="flex items-center justify-center h-full text-center text-slate-500">
        <div>
          <h3 className="text-lg sm:text-xl font-semibold">선택한 날짜에 데이터가 없습니다</h3>
          <p className="text-sm sm:text-base">감정을 기록하여 당신의 하루를 채워보세요!</p>
        </div>
      </div>
    );
  }

  const xAxisTickFormatter = (value: number) => {
    const hour = Math.floor(value);
    return `${String(hour).padStart(2, '0')}:00`;
  };
  
  const yAxisTicks = Array.from({ length: 22 }, (_, i) => i + 1);

  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart
        data={checkpoints}
        margin={{
          top: 10,
          right: 5,
          left: 5,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
        <XAxis 
            dataKey="time" 
            type="number"
            domain={[0, 24]}
            ticks={[0, 4, 8, 12, 16, 20, 24]}
            tickFormatter={xAxisTickFormatter}
            stroke="#94a3b8"
            tick={{ fontSize: 10 }}
        />
        <YAxis 
            dataKey="emotionLevel" 
            type="number"
            domain={[1, 22]}
            reversed={true}
            ticks={yAxisTicks}
            tick={<CustomYAxisTick />}
            stroke="#94a3b8"
            interval={0}
            width={100}
        />
        <Tooltip content={<CustomTooltip />} />
        <Line 
            type="monotone" 
            dataKey="emotionLevel" 
            stroke="#4f46e5" 
            strokeWidth={2}
            activeDot={{ r: 8 }} 
            dot={<CustomizedDot />}
        />
      </LineChart>
    </ResponsiveContainer>
  );
};

export default EmotionChart;