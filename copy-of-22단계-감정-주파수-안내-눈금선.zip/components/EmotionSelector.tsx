import React, { useState } from 'react';
import type { Emotion } from '../types';
import { LogIcon, TrashIcon } from './Icons';

interface EmotionSelectorProps {
  emotions: Emotion[];
  onLogEmotion: (emotionLevel: number, reason: string) => void;
  onClearDayData: () => void;
  onClearAllData: () => void;
  hasDataForDay: boolean;
  hasAnyData: boolean;
  selectedDateKey: string;
}

const EmotionSelector: React.FC<EmotionSelectorProps> = ({ 
    emotions, 
    onLogEmotion, 
    onClearDayData,
    onClearAllData,
    hasDataForDay,
    hasAnyData,
    selectedDateKey
}) => {
  const [selectedEmotion, setSelectedEmotion] = useState<string>('7');
  const [reason, setReason] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      alert('감정을 느끼는 이유를 입력해주세요.');
      document.getElementById('emotion-reason')?.focus();
      return;
    }
    onLogEmotion(parseInt(selectedEmotion, 10), reason);
    setReason('');
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-4 sm:p-6 sticky top-4 z-10">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="emotion-select" className="sr-only">현재 감정 선택</label>
          <select
              id="emotion-select"
              value={selectedEmotion}
              onChange={(e) => setSelectedEmotion(e.target.value)}
              className="w-full h-14 px-4 text-base sm:text-lg bg-slate-100 rounded-xl border-2 border-transparent focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
          >
              {emotions.map((emotion) => (
              <option key={emotion.level} value={emotion.level}>
                  {`${emotion.level}. ${emotion.koreanName}`}
              </option>
              ))}
          </select>
        </div>
        
        <div>
            <label htmlFor="emotion-reason" className="block text-sm font-medium text-slate-700 mb-1">감정을 느끼는 이유 (필수)</label>
            <textarea
                id="emotion-reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="이 감정을 느끼는 이유를 구체적으로 작성해주세요."
                rows={3}
                className="w-full px-4 py-2 text-base bg-slate-100 rounded-xl border-2 border-transparent focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition resize-y"
                required
            />
        </div>

        <button
          type="submit"
          className="w-full h-14 flex items-center justify-center gap-2 px-6 bg-indigo-600 text-white font-bold text-base sm:text-lg rounded-xl hover:bg-indigo-700 transition-colors shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <LogIcon />
          <span>감정 기록</span>
        </button>
      </form>
      
      <div className="mt-4 pt-4 border-t border-slate-200 space-y-4">
        <button
            onClick={onClearDayData}
            disabled={!hasDataForDay}
            className="w-full h-12 flex items-center justify-center gap-2 px-6 bg-amber-500 text-white font-bold rounded-xl hover:bg-amber-600 transition-colors shadow focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500 disabled:bg-slate-300 disabled:cursor-not-allowed"
            >
            <TrashIcon />
            <span>날짜 데이터 삭제</span>
        </button>
        <button
              onClick={onClearAllData}
              disabled={!hasAnyData}
              className="w-full h-12 flex items-center justify-center gap-2 px-6 bg-rose-500 text-white font-bold rounded-xl hover:bg-rose-600 transition-colors shadow focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-rose-500 disabled:bg-slate-300 disabled:cursor-not-allowed"
              >
              <TrashIcon />
              <span>전체 데이터 삭제</span>
          </button>
      </div>
    </div>
  );
};

export default EmotionSelector;