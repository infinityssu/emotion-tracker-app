import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { EMOTIONS_SCALE } from './constants';
import type { Checkpoint } from './types';
import EmotionSelector from './components/EmotionSelector';
import EmotionChart from './components/EmotionChart';
import CalendarView from './components/CalendarView';
import ConfirmationModal from './components/ConfirmationModal';
import { formatDateToYYYYMMDD } from './utils/dateUtils';

interface AllData {
  [key: string]: Checkpoint[];
}

const App: React.FC = () => {
  const [allData, setAllData] = useState<AllData>({});
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [modalState, setModalState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  useEffect(() => {
    try {
      const savedData = localStorage.getItem('emotionTrackerData');
      if (savedData) {
        setAllData(JSON.parse(savedData));
      }
    } catch (error) {
      console.error("Failed to load data from localStorage", error);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('emotionTrackerData', JSON.stringify(allData));
    } catch (error) {
      console.error("Failed to save data to localStorage", error);
    }
  }, [allData]);

  const selectedDateKey = useMemo(() => formatDateToYYYYMMDD(selectedDate), [selectedDate]);
  const checkpointsForSelectedDay = useMemo(() => allData[selectedDateKey] || [], [allData, selectedDateKey]);

  const handleAddCheckpoint = useCallback((emotionLevel: number, reason: string) => {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    const timeAsFloat = currentHour + currentMinute / 60;

    const emotion = EMOTIONS_SCALE.find(e => e.level === emotionLevel);
    if (!emotion) return;

    const newCheckpoint: Checkpoint = {
      time: timeAsFloat,
      emotionLevel: emotion.level,
      koreanName: emotion.koreanName,
      englishName: emotion.englishName,
    };
    
    if (reason.trim()) {
        newCheckpoint.reason = reason.trim();
    }

    setAllData(prevData => {
        const currentDayData = prevData[selectedDateKey] || [];
        const updatedDayData = [...currentDayData, newCheckpoint].sort((a, b) => a.time - b.time);
        return {
            ...prevData,
            [selectedDateKey]: updatedDayData
        };
    });
  }, [selectedDateKey]);

  const handleCloseModal = () => {
    setModalState({ isOpen: false, title: '', message: '', onConfirm: () => {} });
  };
  
  const handleClearDayData = useCallback(() => {
    setModalState({
        isOpen: true,
        title: '날짜 데이터 삭제',
        message: `정말로 ${selectedDateKey}의 모든 감정 기록을 지우시겠습니까?`,
        onConfirm: () => {
            setAllData(prevData => {
                const newData = { ...prevData };
                delete newData[selectedDateKey];
                return newData;
            });
            handleCloseModal();
        }
    });
  }, [selectedDateKey]);

  const handleClearAllData = useCallback(() => {
    setModalState({
        isOpen: true,
        title: '전체 데이터 삭제',
        message: '정말로 모든 날짜의 감정 기록을 전부 지우시겠습니까? 이 작업은 되돌릴 수 없습니다.',
        onConfirm: () => {
            setAllData({});
            handleCloseModal();
        }
    });
  }, []);

  const dataMarkers = useMemo(() => Object.keys(allData), [allData]);

  return (
    <div className="bg-slate-50 min-h-screen font-sans text-slate-800">
      <main className="container mx-auto p-2 sm:p-4 md:p-6">
        <header className="text-center mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-700 tracking-tight">22단계 감정 주파수 안내 눈금선</h1>
        </header>

        <div className="bg-indigo-50 border-l-4 border-indigo-400 text-indigo-800 p-4 rounded-md mb-6" role="alert">
          <p className="font-bold mb-2">매일 순간순간 느껴지는 감정에너지 레벨을 체크해 보세요.</p>
          <p className="text-sm">나의 감정주파수가 주로 어디에 머물러 있는지 알아차리면 나의 감정을 객관적으로 들여다보고 조절하는 힘이 생깁니다.</p>
          <p className="text-sm">엄마가 감정을 조절하는 모습을 보여주면 아이들 또한 스스로 자신의 감정을 조율할 수 있게 됩니다.</p>
          <p className="text-sm">매일 매순간 나의 감정을 알아차려보세요.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 flex flex-col gap-6">
            <CalendarView 
                selectedDate={selectedDate}
                onDateChange={setSelectedDate}
                dataMarkers={dataMarkers}
            />
            <EmotionSelector 
                emotions={EMOTIONS_SCALE} 
                onLogEmotion={handleAddCheckpoint} 
                onClearDayData={handleClearDayData}
                onClearAllData={handleClearAllData}
                hasDataForDay={checkpointsForSelectedDay.length > 0}
                hasAnyData={Object.keys(allData).length > 0}
                selectedDateKey={selectedDateKey}
            />
          </div>
          <div className="lg:col-span-2 bg-white rounded-2xl shadow-lg p-3 sm:p-4 md:p-6">
            <h2 className="text-lg sm:text-xl font-bold text-slate-700 mb-4">나의 감정 여정: <span className="text-indigo-600">{selectedDateKey}</span></h2>
            <div className="w-full h-[600px]">
                <EmotionChart checkpoints={checkpointsForSelectedDay} />
            </div>
          </div>
        </div>
        
        <footer className="text-center mt-8 text-slate-500 text-xs">
            <p>당신의 감정 여정을 통해 웰빙을 찾아보세요. (v2.2.0)</p>
            <p className="mt-1 font-semibold">
                팁: 최신 버전이 안 보이면, 키보드에서 Ctrl+Shift+R 또는 Cmd+Shift+R을 눌러 강력 새로고침 해보세요.
            </p>
        </footer>
      </main>
      <ConfirmationModal
        isOpen={modalState.isOpen}
        onClose={handleCloseModal}
        onConfirm={modalState.onConfirm}
        title={modalState.title}
        message={modalState.message}
      />
    </div>
  );
};

export default App;