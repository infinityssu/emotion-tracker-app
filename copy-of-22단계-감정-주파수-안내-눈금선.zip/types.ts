export interface Emotion {
  level: number;
  koreanName: string;
  englishName: string;
  category: 'Positive' | 'Negative';
}

export interface Checkpoint {
  time: number; // Hour of the day (5-24), as a float for minutes
  emotionLevel: number;
  koreanName: string;
  englishName: string;
  reason?: string;
}
